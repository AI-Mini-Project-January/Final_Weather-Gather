from django.apps import AppConfig


class WeatherappConfig(AppConfig):
    name = 'weatherapp'
